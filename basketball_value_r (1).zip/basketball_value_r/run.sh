#!/bin/bash
cd "$(dirname "$0")"
Rscript install_packages.R && Rscript main.R
