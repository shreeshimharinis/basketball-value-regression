# Run once:  Rscript install_packages.R
pkgs <- c("dplyr", "ggplot2", "caret", "corrplot", "e1071")
new  <- pkgs[!(pkgs %in% installed.packages()[, "Package"])]
if (length(new)) install.packages(new, repos = "https://cloud.r-project.org")
cat("All packages ready.\n")
