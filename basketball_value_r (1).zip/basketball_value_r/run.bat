@echo off
cd /d "%~dp0"
Rscript install_packages.R
Rscript main.R
pause
