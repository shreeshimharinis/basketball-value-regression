# =====================================================================
#  Basketball Player Market Value Prediction Using R
#  Mini project : Linear Regression + Logistic Regression
#  Run from the project folder:   Rscript main.R
# =====================================================================
library(dplyr)
library(ggplot2)
library(caret)

dir.create("outputs", showWarnings = FALSE)
set.seed(123)

# ---------------------------------------------------------------------
# 1. LOAD DATASET
# ---------------------------------------------------------------------
df <- read.csv("data/basketball_players.csv")

df <- df %>% select(overall, potential, age, salary_eur,
                    height_cm, ppg, intl_caps, value_eur)

cat("\n--- Stage 0: Dataset ---\n")
print(head(df))
cat("Dimensions:", dim(df), "\n")
str(df)
print(summary(df))

# ---------------------------------------------------------------------
# 2. DATA CLEANING
# ---------------------------------------------------------------------
cat("\n--- Stage 1: Data cleaning ---\n")
cat("Missing values per column:\n")
print(colSums(is.na(df)))

df <- df %>% filter(!is.na(value_eur))                      # target missing -> drop
df$salary_eur[is.na(df$salary_eur)] <- median(df$salary_eur, na.rm = TRUE)
cat("NA left after cleaning:", sum(is.na(df)), "\n")

cat("Duplicate rows:", sum(duplicated(df)), "\n")
df <- df[!duplicated(df), ]
cat("Rows after cleaning:", nrow(df), "\n")

# Binary target: High Value Player = market value >= 2,000,000 EUR
df$high_value <- factor(ifelse(df$value_eur >= 2e6, "Yes", "No"),
                        levels = c("No", "Yes"))
print(table(df$high_value))

# ---------------------------------------------------------------------
# 3. DATA VISUALIZATION  (plots saved in outputs/)
# ---------------------------------------------------------------------
p1 <- ggplot(df, aes(value_eur)) +
  geom_histogram(bins = 50, fill = "darkorange") +
  labs(title = "Distribution of Player Value", x = "value_eur")
ggsave("outputs/01_value_histogram.png", p1, width = 7, height = 4)

p2 <- ggplot(df, aes(log(value_eur))) +
  geom_histogram(bins = 50, fill = "steelblue") +
  labs(title = "Distribution of log(Value)", x = "log(value_eur)")
ggsave("outputs/02_log_value_histogram.png", p2, width = 7, height = 4)

p3 <- ggplot(df, aes(overall, value_eur)) +
  geom_point(alpha = .3, color = "darkorange") +
  geom_smooth(method = "lm", formula = y ~ x) +
  scale_y_log10() +
  labs(title = "Overall vs Market Value")
ggsave("outputs/03_overall_vs_value.png", p3, width = 7, height = 4)

num_cols <- df %>% select(-high_value)
cor_mat  <- cor(num_cols)
cat("\nCorrelation with value_eur:\n")
print(round(cor_mat[, "value_eur"], 2))

png("outputs/04_correlation_matrix.png", width = 800, height = 700)
corrplot::corrplot(cor_mat, method = "color")
dev.off()

# ---------------------------------------------------------------------
# 4. DATA SPLITTING  (80% train / 20% test)
# ---------------------------------------------------------------------
idx   <- createDataPartition(df$value_eur, p = 0.8, list = FALSE)
train <- df[idx, ]
test  <- df[-idx, ]
cat("\nTrain rows:", nrow(train), " Test rows:", nrow(test), "\n")

# ---------------------------------------------------------------------
# 5. MODEL TRAINING
# ---------------------------------------------------------------------
# Model 1: Linear Regression -> predicts log(value)
lm_model <- lm(log(value_eur) ~ overall + potential + age + salary_eur +
                 height_cm + ppg + intl_caps,
               data = train)

# Model 2: Logistic Regression -> predicts High Value (Yes / No)
glm_model <- glm(high_value ~ overall + potential + age + salary_eur,
                 data = train, family = binomial)

# ---------------------------------------------------------------------
# 6. LINEAR REGRESSION RESULTS
# ---------------------------------------------------------------------
cat("\n===== Linear Regression =====\n")
print(summary(lm_model))

pred_log <- predict(lm_model, test)
pred     <- exp(pred_log)               # back to euros
actual_l <- log(test$value_eur)

rmse <- RMSE(pred_log, actual_l)
mae  <- MAE(pred_log, actual_l)
r2   <- R2(pred_log, actual_l)
cat(sprintf("RMSE (log) = %.3f | MAE (log) = %.3f | R-squared = %.3f\n",
            rmse, mae, r2))

p4 <- ggplot(data.frame(actual = actual_l, predicted = pred_log),
             aes(actual, predicted)) +
  geom_point(alpha = .4, color = "darkorange") +
  geom_abline(slope = 1, intercept = 0, color = "red", linewidth = 1) +
  labs(title = "Linear Regression: Actual vs Predicted (log value)")
ggsave("outputs/05_lm_actual_vs_predicted.png", p4, width = 7, height = 4)

# ---------------------------------------------------------------------
# 7. LOGISTIC REGRESSION RESULTS
# ---------------------------------------------------------------------
cat("\n===== Logistic Regression =====\n")
print(summary(glm_model))
cat("\nOdds ratios:\n")
print(round(exp(coef(glm_model)), 4))

prob <- predict(glm_model, test, type = "response")
cls  <- factor(ifelse(prob > 0.5, "Yes", "No"), levels = c("No", "Yes"))
cm   <- confusionMatrix(cls, test$high_value, positive = "Yes")
print(cm)

# AUC without extra packages (rank / Mann-Whitney formula)
auc <- function(p, y) {
  y <- as.integer(y == "Yes")
  r <- rank(p)
  n1 <- sum(y == 1); n0 <- sum(y == 0)
  (sum(r[y == 1]) - n1 * (n1 + 1) / 2) / (n1 * n0)
}
auc_val <- auc(prob, test$high_value)
cat(sprintf("AUC = %.3f\n", auc_val))

# ---------------------------------------------------------------------
# 8. MODEL COMPARISON + SAVE METRICS
# ---------------------------------------------------------------------
metrics <- data.frame(
  Model  = c("Linear Regression", "Logistic Regression"),
  R2     = c(round(r2, 3), NA),
  RMSE_log = c(round(rmse, 3), NA),
  Accuracy = c(NA, round(unname(cm$overall["Accuracy"]), 3)),
  AUC    = c(NA, round(auc_val, 3))
)
print(metrics)
write.csv(metrics, "outputs/model_metrics.csv", row.names = FALSE)

# ---------------------------------------------------------------------
# 9. DEMO: predict a new player
# ---------------------------------------------------------------------
new_player <- data.frame(overall = 82, potential = 85, age = 24,
                         salary_eur = 20000, height_cm = 200,
                         ppg = 18, intl_caps = 30)
est <- exp(predict(lm_model, new_player))
p_hi <- predict(glm_model, new_player, type = "response")
cat(sprintf("\nNew player estimated value: EUR %s\n", format(round(est), big.mark = ",")))
cat(sprintf("Probability of High Value : %.1f%%\n", 100 * p_hi))
cat("\nDone. Plots and metrics are in the outputs/ folder.\n")
